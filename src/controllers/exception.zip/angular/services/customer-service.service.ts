import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { CustomerServiceModel } from '../models/customer-service-model'; 
import { Page } from '../models/page'; 


@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService{

  constructor(private http: HttpClient) { }

  
findAll({sector, concluded, evaluation, town, beginService, endService, }: CustomerServiceModel,page: number = null, size: number = null): Observable<Page<CustomerServiceModel>>{
    let filters = '?';
    if(sector != null){
      filters += `sector=${sector}&`;
    }

    if(concluded != null){
      filters += `concluded=${concluded}&`;
    }

    if(evaluation != null){
      filters += `evaluation=${evaluation}&`;
    }

    if(town != null){
      filters += `town=${town}&`;
    }

    if(beginService != null){
      filters += `beginService=${beginService}&`;
    }

    if(endService != null){
      filters += `endService=${endService}&`;
    }

    if(page != null){
      filters += 'page=${page}&';
    }

    if(size != null){
      filters += 'size=${size}&';
    }

    filters = filters.substring(0, filters.length -1);
    return this.http.get<Page<CustomerServiceModel>>(`${environment.apiEndpoint}/customer-service${filters}`);
  }
  
findById(id: number): Observable<CustomerServiceModel>{
    return this.http.get<CustomerServiceModel>(`${environment.apiEndpoint}/customer-service/${id}`);
  }
  
insert(model: CustomerServiceModel): Observable<CustomerServiceModel>{
    return this.http.post<CustomerServiceModel>(`${environment.apiEndpoint}/customer-service`,model);
  }
  
delete(id: number): Observable<CustomerServiceModel>{
    return this.http.delete<CustomerServiceModel>(`${environment.apiEndpoint}/customer-service/${id}`);
  }
  
update(model: CustomerServiceModel, id: number): Observable<CustomerServiceModel>{
    return this.http.put<CustomerServiceModel>(`${environment.apiEndpoint}/customer-service/${id}`,model);
  }
}
