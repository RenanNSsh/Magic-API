import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { CitizenModel } from '../models/citizen-model'; 
import { Page } from '../models/page'; 


@Injectable({
  providedIn: 'root'
})
export class CitizenService{

  constructor(private http: HttpClient) { }

  
findAll(page: number = null, size: number = null): Observable<Page<CitizenModel>>{
    let filters = '?';
    if(page != null){
      filters += 'page=${page}&';
    }

    if(size != null){
      filters += 'size=${size}&';
    }

    filters = filters.substring(0, filters.length -1);
    return this.http.get<Page<CitizenModel>>(`${environment.apiEndpoint}/citizen${filters}`);
  }
  
findById(id: number): Observable<CitizenModel>{
    return this.http.get<CitizenModel>(`${environment.apiEndpoint}/citizen/${id}`);
  }
  
insert(model: CitizenModel): Observable<CitizenModel>{
    return this.http.post<CitizenModel>(`${environment.apiEndpoint}/citizen`,model);
  }
  
delete(id: number): Observable<CitizenModel>{
    return this.http.delete<CitizenModel>(`${environment.apiEndpoint}/citizen/${id}`);
  }
  
update(model: CitizenModel, id: number): Observable<CitizenModel>{
    return this.http.put<CitizenModel>(`${environment.apiEndpoint}/citizen/${id}`,model);
  }
}
