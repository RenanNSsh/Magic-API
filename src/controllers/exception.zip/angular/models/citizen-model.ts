
export interface CitizenModel{
  id: number;
}
