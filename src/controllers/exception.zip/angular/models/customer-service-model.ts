import { CitizenModel } from './citizen-model';

export interface CustomerServiceModel{
  id: number;
  sector: string;
  concluded: boolean;
  evaluation: number;
  town: string;
  beginService: string;
  endService: string;
  citizen: CitizenModel;
}
