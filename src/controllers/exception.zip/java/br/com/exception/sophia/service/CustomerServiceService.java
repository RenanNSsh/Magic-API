package br.com.exception.sophia.service;

import br.com.exception.sophia.service.exceptions.ObjectNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import java.util.List;

import br.com.exception.sophia.repository.CustomerServiceRepository;

import br.com.exception.sophia.model.CustomerServiceModel;
import  br.com.exception.sophia.specification.CustomerServiceSpecification;

@Service
public class CustomerServiceService {

  @Autowired
  private CustomerServiceRepository repository;

  @Transactional
  public CustomerServiceModel insert(CustomerServiceModel model){
    model.setId(null);
    return repository.save(model);
  }

  public CustomerServiceModel delete(Integer id){
    CustomerServiceModel model = findById(id);
    repository.deleteById(id);
    return model;
  }

  public CustomerServiceModel findById(Integer id){
    Optional<CustomerServiceModel> model = repository.findById(id);
    return model.orElseThrow(()-> new ObjectNotFoundException(
        "Objeto não encontrado! Id: " + id + ", Tipo: " + CustomerServiceModel.class.getName()));
  }

  public Page<CustomerServiceModel> findPaginated(String sector,Boolean concluded,Double evaluation,String town,String beginService,String endService,CITIZENitizenModel citizen, Pageable pageable){
    if(sector == null && concluded == null && evaluation == null && town == null && beginService == null && endService == null && citizen == null){
      return repository.findAll(pageable);
    }
    Specification<CustomerServiceModel> specification = null;
    if(sector != null){
        specification = Specification.where(CustomerServiceSpecification.sector(sector));
    }

    if(concluded != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.concluded(concluded));
      }else{
        specification = specification.and(CustomerServiceSpecification.concluded(concluded));
      }
    }

    if(evaluation != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.evaluation(evaluation));
      }else{
        specification = specification.and(CustomerServiceSpecification.evaluation(evaluation));
      }
    }

    if(town != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.town(town));
      }else{
        specification = specification.and(CustomerServiceSpecification.town(town));
      }
    }

    if(beginService != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.beginService(beginService));
      }else{
        specification = specification.and(CustomerServiceSpecification.beginService(beginService));
      }
    }

    if(endService != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.endService(endService));
      }else{
        specification = specification.and(CustomerServiceSpecification.endService(endService));
      }
    }

    if(citizen != null){
      if(specification == null){
        specification = Specification.where(CustomerServiceSpecification.citizen(citizen));
      }else{
        specification = specification.and(CustomerServiceSpecification.citizen(citizen));
      }
    }

    return repository.findAll(specification, pageable);
  }

  public CustomerServiceModel update(CustomerServiceModel model, Integer id){
    model.setId(id);
    CustomerServiceModel modelUpdated = repository.save(model);
    return modelUpdated;
  }


}