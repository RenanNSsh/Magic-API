package br.com.exception.sophia.specification;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.repository.query.Param;

import br.com.exception.sophia.model.CustomerServiceModel;


public class CustomerServiceSpecification {

  public static Specification<CustomerServiceModel> sector(String sector){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.like(root.get("sector"), sector);
  }
  public static Specification<CustomerServiceModel> concluded(Boolean concluded){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.equal(root.get("concluded"), concluded);
  }
  public static Specification<CustomerServiceModel> evaluation(Double evaluation){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.equal(root.get("evaluation"), evaluation);
  }
  public static Specification<CustomerServiceModel> town(String town){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.like(root.get("town"), town);
  }
  public static Specification<CustomerServiceModel> beginService(String beginService){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.like(root.get("beginService"), beginService);
  }
  public static Specification<CustomerServiceModel> endService(String endService){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.like(root.get("endService"), endService);
  }
  public static Specification<CustomerServiceModel> citizen(CITIZENitizenModel citizen){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.equal(root.get("citizen"), citizen);
  }

}