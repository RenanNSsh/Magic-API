package br.com.exception.sophia.specification;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.repository.query.Param;

import br.com.exception.sophia.model.CitizenModel;


public class CitizenSpecification {

  public static Specification<CitizenModel> customerService(CUSTOMERSERVICEustomerServiceModel customerService){
    return (root, criteriaQuery, criteriaBuilder) ->
      criteriaBuilder.equal(root.get("customerService"), customerService);
  }

}