package br.com.exception.sophia.model;

import javax.persistence.Entity;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Id;
import java.io.Serializable;

import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.exception.sophia.model.CitizenModel;
@Entity
public class CustomerServiceModel implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ID_CUSTOMER_SERVICE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CUSTOMER_SERVICE_SEQ")
  @SequenceGenerator(name = "CUSTOMER_SERVICE_SEQ", sequenceName = "CUSTOMER_SERVICE_SEQ", allocationSize = 1)
  private Integer id;
  private String sector;
  private Boolean concluded;
  private Double evaluation;
  private String town;
  @Temporal(TemporalType.TIMESTAMP)
  private Date beginService;
  @Temporal(TemporalType.TIMESTAMP)
  private Date endService;
  @OneToOne(mappedBy = "customerService",cascade=CascadeType.ALL)
  CitizenModel citizen;

  public CustomerServiceModel() {

  }

 // Getter Methods 

  public Integer getId() {
    return id;
  }

  public String getSector() {
    return sector;
  }

  public Boolean getConcluded() {
    return concluded;
  }

  public Double getEvaluation() {
    return evaluation;
  }

  public String getTown() {
    return town;
  }

  public Date getBeginService() {
    return beginService;
  }

  public Date getEndService() {
    return endService;
  }

  public CitizenModel getCitizen() {
    return citizen;
  }

 // Setter Methods 

  public void setId( Integer id ) {
    this.id = id;
  }

  public void setSector( String sector ) {
    this.sector = sector;
  }

  public void setConcluded( Boolean concluded ) {
    this.concluded = concluded;
  }

  public void setEvaluation( Double evaluation ) {
    this.evaluation = evaluation;
  }

  public void setTown( String town ) {
    this.town = town;
  }

  public void setBeginService( Date beginService ) {
    this.beginService = beginService;
  }

  public void setEndService( Date endService ) {
    this.endService = endService;
  }

  public void setCitizen( CitizenModel citizen ) {
    this.citizen = citizen;
  }
}