package br.com.exception.sophia.model;

import javax.persistence.Entity;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Id;
import java.io.Serializable;

import br.com.exception.sophia.model.CustomerServiceModel;
@Entity
public class CitizenModel implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ID_CITIZEN")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CITIZEN_SEQ")
  @SequenceGenerator(name = "CITIZEN_SEQ", sequenceName = "CITIZEN_SEQ", allocationSize = 1)
  private Integer id;
  @OneToOne
  @MapsId
  CustomerServiceModel customerService;

  public CitizenModel() {

  }

 // Getter Methods 

  public Integer getId() {
    return id;
  }

  public CustomerServiceModel getCustomerService() {
    return customerService;
  }

 // Setter Methods 

  public void setId( Integer id ) {
    this.id = id;
  }

  public void setCustomerService( CustomerServiceModel customerService ) {
    this.customerService = customerService;
  }
}