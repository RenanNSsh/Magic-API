package br.com.exception.sophia.controller;

import org.springframework.http.ResponseEntity;
import java.net.URI;
import javax.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.exception.sophia.service.CustomerServiceService;

import br.com.exception.sophia.model.CustomerServiceModel;

@RestController
@CrossOrigin()
@RequestMapping(value="/customer-service")
public class CustomerServiceController {

  @Autowired
  private CustomerServiceService service;

  @PostMapping
  public ResponseEntity<CustomerServiceModel> insert(@Valid @RequestBody CustomerServiceModel model){
    CustomerServiceModel modelCreated = service.insert(model);
     URI location = ServletUriComponentsBuilder
                         .fromCurrentRequest()
                         .path("{/id}")                         .buildAndExpand(modelCreated.getId()).toUri();
    return ResponseEntity.created(location).body(modelCreated);
  };

  @DeleteMapping("/{id}")
  public ResponseEntity<CustomerServiceModel> delete(@PathVariable Integer id){
    CustomerServiceModel model = service.delete(id);
    return ResponseEntity.ok().body(model);
  };

  @GetMapping("/{id}")
  public ResponseEntity<CustomerServiceModel> findById(@PathVariable Integer id){
    CustomerServiceModel model = service.findById(id);
    return ResponseEntity.ok().body(model);
  };

  @GetMapping
  public ResponseEntity<Page<CustomerServiceModel>> findPaginated(@RequestParam(required=false) Integer id,@RequestParam(required=false) String sector,@RequestParam(required=false) Boolean concluded,@RequestParam(required=false) Double evaluation,@RequestParam(required=false) String town,@RequestParam(required=false) String beginService,@RequestParam(required=false) String endService,@RequestParam(required=false) CITIZENitizenModel citizen, Pageable pageable){
    return ResponseEntity.ok().body(service.findPaginated( sector, concluded, evaluation, town, beginService, endService, citizen, pageable));
  };

  @PutMapping("/{id}")
  public ResponseEntity<CustomerServiceModel> update(@PathVariable Integer id, @RequestBody CustomerServiceModel model){
    CustomerServiceModel modelUpdated = service.update(model, id);
    return ResponseEntity.ok().body(modelUpdated);
  };


}