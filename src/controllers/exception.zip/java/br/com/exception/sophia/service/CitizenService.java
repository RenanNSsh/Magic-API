package br.com.exception.sophia.service;

import br.com.exception.sophia.service.exceptions.ObjectNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import java.util.List;

import br.com.exception.sophia.repository.CitizenRepository;

import br.com.exception.sophia.model.CitizenModel;
import  br.com.exception.sophia.specification.CitizenSpecification;

@Service
public class CitizenService {

  @Autowired
  private CitizenRepository repository;

  @Transactional
  public CitizenModel insert(CitizenModel model){
    model.setId(null);
    return repository.save(model);
  }

  public CitizenModel delete(Integer id){
    CitizenModel model = findById(id);
    repository.deleteById(id);
    return model;
  }

  public CitizenModel findById(Integer id){
    Optional<CitizenModel> model = repository.findById(id);
    return model.orElseThrow(()-> new ObjectNotFoundException(
        "Objeto não encontrado! Id: " + id + ", Tipo: " + CitizenModel.class.getName()));
  }

  public Page<CitizenModel> findPaginated(CUSTOMERSERVICEustomerServiceModel customerService, Pageable pageable){
    if(customerService == null){
      return repository.findAll(pageable);
    }
    Specification<CitizenModel> specification = null;
    if(customerService != null){
        specification = Specification.where(CitizenSpecification.customerService(customerService));
    }

    return repository.findAll(specification, pageable);
  }

  public CitizenModel update(CitizenModel model, Integer id){
    model.setId(id);
    CitizenModel modelUpdated = repository.save(model);
    return modelUpdated;
  }


}