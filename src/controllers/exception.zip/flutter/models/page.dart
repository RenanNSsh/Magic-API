

class Page<T>{
  List<Map<String, dynamic>> content;
  List<T> contentObj;
  Pageable pageable;
  int totalPages;
  bool last;
  int totalElements;
  int size;
  int number;
  Sort sort;
  int numberOfElements;
  bool first;
  bool empty;
  Page({
    this.content,
    this.contentObj,
    this.pageable,
    this.totalPages,
    this.last,
    this.totalElements,
    this.size,
    this.number,
    this.sort,
    this.numberOfElements,
    this.first,
    this.empty
  });

  Page.fromJson(Map<String, dynamic> json) {
    content = json['content'];
    contentObj = json['contentObj'];
    if(json['pageable'] != null){
      pageable = Pageable.fromJson(json['pageable']);
    }
    totalPages = json['totalPages'];
    last = json['last'];
    totalElements = json['totalElements'];
    size = json['size'];
    number = json['number'];
    if(json['sort'] != null){
      sort = Sort.fromJson(json['sort']);
    }
    numberOfElements = json['numberOfElements'];
    first = json['first'];
    empty = json['empty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();

    data['content'] = this.content;
    data['contentObj'] = this.contentObj;
    if(this.pageable != null){
      data['pageable'] = this.pageable.toJson();
    }
    data['totalPages'] = this.totalPages;
    data['last'] = this.last;
    data['totalElements'] = this.totalElements;
    data['size'] = this.size;
    data['number'] = this.number;
    if(this.sort != null){
      data['sort'] = this.sort.toJson();
    }
    data['numberOfElements'] = this.numberOfElements;
    data['first'] = this.first;
    data['empty'] = this.empty;
  }
}



class Pageable{
  Sort sort;
  int offset;
  int pageSize;
  int pageNumber;
  bool paged;
  bool unpaged;
  Pageable({
    this.sort,
    this.offset,
    this.pageSize,
    this.pageNumber,
    this.paged,
    this.unpaged
  });

  Pageable.fromJson(Map<String, dynamic> json) {
    if(json['sort'] != null){
      sort = Sort.fromJson(json['sort']);
    }
    offset = json['offset'];
    pageSize = json['pageSize'];
    pageNumber = json['pageNumber'];
    paged = json['paged'];
    unpaged = json['unpaged'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();

    if(this.sort != null){
      data['sort'] = this.sort.toJson();
    }
    data['offset'] = this.offset;
    data['pageSize'] = this.pageSize;
    data['pageNumber'] = this.pageNumber;
    data['paged'] = this.paged;
    data['unpaged'] = this.unpaged;
  }
}



class Sort{
  bool sorted;
  bool unsorted;
  bool empty;
  Sort({
    this.sorted,
    this.unsorted,
    this.empty
  });

  Sort.fromJson(Map<String, dynamic> json) {
    sorted = json['sorted'];
    unsorted = json['unsorted'];
    empty = json['empty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();

    data['sorted'] = this.sorted;
    data['unsorted'] = this.unsorted;
    data['empty'] = this.empty;
  }
}
