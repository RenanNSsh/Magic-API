import 'package:SophIA/models/citizen_model.dart';

class CustomerServiceModel{
  int id;
  String sector;
  bool concluded;
  double evaluation;
  String town;
  String beginService;
  String endService;
  CitizenModel citizen;
  CustomerServiceModel({
    this.id,
    this.sector,
    this.concluded,
    this.evaluation,
    this.town,
    this.beginService,
    this.endService,
    this.citizen
  });

  CustomerServiceModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    sector = json['sector'];
    concluded = json['concluded'];
    evaluation = json['evaluation'];
    town = json['town'];
    beginService = json['beginService'];
    endService = json['endService'];
    if(json['citizen'] != null){
      citizen = CitizenModel.fromJson(json['citizen']);
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();

    data['id'] = this.id;
    data['sector'] = this.sector;
    data['concluded'] = this.concluded;
    data['evaluation'] = this.evaluation;
    data['town'] = this.town;
    data['beginService'] = this.beginService;
    data['endService'] = this.endService;
    if(this.citizen != null){
      data['citizen'] = this.citizen.toJson();
    }
  }
}
