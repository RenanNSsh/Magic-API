import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:SophIA/config.dart';
import 'package:SophIA/models/page.dart'; 
import 'package:SophIA/models/customer_service_model.dart'; 


class CustomerServiceService{


  Future<Page<CustomerServiceModel>> findAll({String sector, bool concluded, double evaluation, String town, String beginService, String endService, int page, int size}){
    var filters = '?';
    if(sector != null){
      filters += 'sector=$sector&';
    }

    if(concluded != null){
      filters += 'concluded=$concluded&';
    }

    if(evaluation != null){
      filters += 'evaluation=$evaluation&';
    }

    if(town != null){
      filters += 'town=$town&';
    }

    if(beginService != null){
      filters += 'beginService=$beginService&';
    }

    if(endService != null){
      filters += 'endService=$endService&';
    }

    if(page != null){
      filters += 'page=$page&';
    }

    if(size != null){
      filters += 'size=$size&';
    }

    filters = filters.substring(0, filters.length -1);
    return http.get('$apiEndpoint/customer-service?$filters').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      Page<CustomerServiceModel> model = Page.fromJson(modelJSON); 
      model.contentObj = model.content.map<CustomerServiceModel>((modelJson) => CustomerServiceModel.fromJson(modelJson)).toList(); 
      return model; 
    });
  }
  Future<CustomerServiceModel> findById(int id){
    return http.get('$apiEndpoint/customer-service/$id').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CustomerServiceModel model = CustomerServiceModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CustomerServiceModel> insert(CustomerServiceModel model){
    return http.post('$apiEndpoint/customer-service',headers: {'Content-type': 'application/json'},body: json.encode(model)).then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CustomerServiceModel model = CustomerServiceModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CustomerServiceModel> delete(int id){
    return http.delete('$apiEndpoint/customer-service/$id').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CustomerServiceModel model = CustomerServiceModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CustomerServiceModel> update(CustomerServiceModel model, int id){
    return http.put('$apiEndpoint/customer-service/$id',headers: {'Content-type': 'application/json'},body: json.encode(model)).then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CustomerServiceModel model = CustomerServiceModel.fromJson(modelJSON); 
      return model; 
    });
  }
}
