import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:SophIA/config.dart';
import 'package:SophIA/models/page.dart'; 
import 'package:SophIA/models/citizen_model.dart'; 


class CitizenService{


  Future<Page<CitizenModel>> findAll({int page, int size}){
    var filters = '?';
    if(page != null){
      filters += 'page=$page&';
    }

    if(size != null){
      filters += 'size=$size&';
    }

    filters = filters.substring(0, filters.length -1);
    return http.get('$apiEndpoint/citizen?$filters').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      Page<CitizenModel> model = Page.fromJson(modelJSON); 
      model.contentObj = model.content.map<CitizenModel>((modelJson) => CitizenModel.fromJson(modelJson)).toList(); 
      return model; 
    });
  }
  Future<CitizenModel> findById(int id){
    return http.get('$apiEndpoint/citizen/$id').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CitizenModel model = CitizenModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CitizenModel> insert(CitizenModel model){
    return http.post('$apiEndpoint/citizen',headers: {'Content-type': 'application/json'},body: json.encode(model)).then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CitizenModel model = CitizenModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CitizenModel> delete(int id){
    return http.delete('$apiEndpoint/citizen/$id').then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CitizenModel model = CitizenModel.fromJson(modelJSON); 
      return model; 
    });
  }
  Future<CitizenModel> update(CitizenModel model, int id){
    return http.put('$apiEndpoint/citizen/$id',headers: {'Content-type': 'application/json'},body: json.encode(model)).then((response) {
      var modelJSON = json.decode(Utf8Decoder().convert(response.bodyBytes)); 
      CitizenModel model = CitizenModel.fromJson(modelJSON); 
      return model; 
    });
  }
}
